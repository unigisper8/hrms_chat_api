<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hrms_gst_m extends MY_Model
{
    public $_table_name = 'MAN_MOB_HRMS_GST';

    public function __construct()
    {
        parent::__construct();
    }
}