<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hrms_timeoff_title_m extends MY_Model
{
    public $_table_name = 'MAN_MOB_HRMS_TIMEOFF_TITLE';

    public function __construct()
    {
        parent::__construct();
    }

    public function get_list()
    {
        $_table_name = 'MAN_MOB_HRMS_TIMEOFF_TITLE';
        $sql = "select * from $_table_name where 1 order by `Date` desc";
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    public function get_by_employee_ids($users)
    {
        if (isset($users) && sizeof($users) > 0) {
            $str_users = implode("','", $users);
            $in = '';
            if ($str_users != '') {
                $in = "EMPLOYEE_ID in ('$str_users') ";
            }
            $_table_name = 'MAN_MOB_HRMS_TIMEOFF_TITLE';
            $sql = "select * from $_table_name where $in order by `Date` desc";
            $query = $this->db->query($sql);
            return $query->result_array();
        } else {
            return array();
        }
    }

    public function get_by_employee_id($id)
    {
        $_table_name = 'MAN_MOB_HRMS_TIMEOFF_TITLE';
        $sql = "select * from $_table_name where EMPLOYEE_ID = '$id' order by `Date` desc";
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    public function get_by_id($id)
    {
        $data = $this->get_by(array(
            ID => $id,
        ), true);

        return $data;
    }

    public function check_duplicated($employeeID, $title, $country, $type, $date, $startTime, $endTime, $description, $status)
    {
        $data = $this->get_by(array(
            EMPLOYEE_ID     => $employeeID,
            TIMEOFF_TITLE   => $title,
            COUNTRY         => $country,
            TYPE            => $type,
            DATE            => $date,
            START_HOUR      => $startTime,
            END_HOUR        => $endTime,
            DESCRIPTION     => $description,
            STATUS          => $status
        ), false);

        if (sizeof($data) > 0)
            return true;
        else
            return false;
    }

    public function update_status($id, $status)
    {
        $result = $this->update(array(
            STATUS => $status
        ), $id);

        return $result;
    }

    public function get_list_in_month()
    {
        $_table_name = 'MAN_MOB_HRMS_TIMEOFF_TITLE';
        $sql = "select `Type` as category, COUNT(*) as times, SUM(time_to_sec(TIMEDIFF(EndHour, StartHour)) / 3600) as total_hours from $_table_name where YEAR(`Date`) = YEAR(CURRENT_DATE()) AND MONTH(`Date`) = MONTH(CURRENT_DATE()) GROUP BY `Type`";
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    public function get_list_in_year()
    {
        $_table_name = 'MAN_MOB_HRMS_TIMEOFF_TITLE';
        $sql = "select `Type` as category, COUNT(*) as times, SUM(time_to_sec(TIMEDIFF(EndHour, StartHour)) / 3600) as total_hours from $_table_name where YEAR(`Date`) = YEAR(CURRENT_DATE()) GROUP BY `Type`";
        $query = $this->db->query($sql);
        return $query->result_array();
    }
}